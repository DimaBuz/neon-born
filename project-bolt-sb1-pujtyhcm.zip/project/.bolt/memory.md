# Project memory

## Product intent & audience

- Project name: "Neon Born" — inferred from GitHub repo link (`Derden86/neon-born`)
- Intent: Web application project viewer (specific app type unknown — could be landing page, game, dashboard, etc.)
- Target audience: Unknown — awaiting clarification
- No code currently exists in project directory; only a `.env` file present

## Brand personality & voice

- Name suggests neon/synthwave aesthetic ("Neon Born") — likely bold, retro-futuristic, vibrant
- Tone: Unconfirmed; awaiting user input on brand direction

## Visual design & UX direction

- No design context yet inferred; project directory is empty
- Name implies potential dark-mode-forward design with neon accent colors (cyan, magenta, electric blue/purple)
- All visual direction pending user clarification

## Decisions, constraints & rationale

- External GitHub URLs cannot be accessed/fetched directly from the environment
- Project must be seeded from user-provided description or manually imported code
- No `.bolt/prompt` instructions exist for this project

## Open questions & assumptions

- What type of web app is "Neon Born"? (landing page, game, dashboard, portfolio, etc.)
- What are the intended features and functionality?
- Is there existing code to import, or should it be built from scratch?
- What design aesthetic, color palette, and typography are desired?
- Who is the target audience?
- Assumption: "Neon Born" may relate to neon/synthwave visual themes based on naming convention — unconfirmed